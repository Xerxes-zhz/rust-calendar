# Standard Library
import warnings
from datetime import datetime


def _type_check(element, cls: object) -> bool:
    return isinstance(element, cls)


def _time_format_check(element, format: str) -> bool:
    """
    :desc: 返回是否能匹配某种日期格式
    :param {*} element
    :param {str} format
    :return {bool}
    """
    try:
        datetime.strptime(element, format)
    except ValueError:
        return False
    else:
        return True


class Warning(object):
    @staticmethod
    def warn(message):
        warnings.warn(message)


class InputCheck(object):
    @staticmethod
    def num_check(element):
        """
        :desc: 数字检查
        :param {*} element
        :raise: TypeError
        """
        if not (_type_check(element, int) or _type_check(element, float)):
            raise TypeError(f"{element} is not a number")

    @staticmethod
    def type_check(element, cls: object):
        """
        :desc: 数字检查
        :param {*} element
        :raise: TypeError
        """
        if not _type_check(element, cls):
            raise TypeError(f"{element} is not {cls}")

    @staticmethod
    def option_check(element, option: list):
        """
        :desc: 选项检查
        :param {*} element
        :raise: TypeError
        """
        if element not in option:
            raise ValueError(f"{element} is not in {option}")

    @staticmethod
    def time_format_check(element, format):
        """
        :desc: 时间格式检查
        :param {*} element
        :raise: TypeError
        """
        if not _time_format_check(element, format):
            raise ValueError(f"{element} can't match format {format}")

    @staticmethod
    def date_check(element):
        """
        :desc: 日期检查检查
        :param {*} element
        :raise: TypeError
        """
        InputCheck.time_format_check(str(element), "%Y%m%d")


class DataExistsError(OSError):
    def __init__(self, *args: object) -> None:
        super().__init__(*args)


if __name__ == "__main__":
    InputCheck.num_check(0)
    InputCheck.date_check("20230212")
