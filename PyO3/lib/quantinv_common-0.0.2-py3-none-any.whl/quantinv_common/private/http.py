#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: zhanghaozhe
# @created on: 2023-04-13 11:14:31
# @desc  : http操作的扩展


# Third Party Library
import requests
from requests.adapters import HTTPAdapter


def _requests_session_getter(max_retries):
    s = requests.session()
    s.mount("http://", HTTPAdapter(max_retries))
    s.mount("https://", HTTPAdapter(max_retries))
    return s


def get(url, timeout=5, max_retries=3, **kwargs):
    s = _requests_session_getter(max_retries)
    return s.request("get", url=url, timeout=timeout, **kwargs)


def put(url, timeout=5, max_retries=3, **kwargs):
    s = _requests_session_getter(max_retries)
    return s.request("put", url=url, timeout=timeout, **kwargs)


def post(url, timeout=5, max_retries=3, **kwargs):
    s = _requests_session_getter(max_retries)
    return s.request("post", url=url, timeout=timeout, **kwargs)


def delete(url, timeout=5, max_retries=3, **kwargs):
    s = _requests_session_getter(max_retries)
    return s.request("delete", url=url, timeout=timeout, **kwargs)


def patch(url, timeout=5, max_retries=3, **kwargs):
    s = _requests_session_getter(max_retries)
    return s.request("patch", url=url, timeout=timeout, **kwargs)
