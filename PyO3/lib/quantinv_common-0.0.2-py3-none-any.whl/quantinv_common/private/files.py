# Standard Library
import os
import filecmp
from os.path import join

# My Library
from quantinv_common.config import CACHE_DIR_NAME


def dir_cmp(dir1, dir2):
    _cmp = filecmp.dircmp(dir1, dir2)

    return {
        "diff": _cmp.diff_files,
        "files_only_in_dir1": _cmp.left_only,
        "files_in_dir1": _cmp.left_list,
        "files_only_in_dir2": _cmp.right_only,
        "files_in_dir2": _cmp.right_list,
    }


def file_cmp(file1, file2):
    return filecmp.cmp(file1, file2)


# 根据系统得出缓存目录位置
def get_cache_dir(os_type):
    # 获取用户数据缓存目录
    if os_type == "Windows":
        cache_dir = join(os.getenv("PROGRAMDATA"), CACHE_DIR_NAME)
    elif os_type == "Linux":
        cache_dir = join(os.path.expanduser("~"), CACHE_DIR_NAME)
    elif os_type == "Darwin":
        cache_dir = join(os.path.expanduser("~/Library/Application Support"), CACHE_DIR_NAME)
    else:
        raise OSError(f"This operate system ({os_type}) is not supported")
    # 创建缓存目录
    if not os.path.exists(cache_dir):
        os.mkdir(cache_dir)
    return cache_dir
