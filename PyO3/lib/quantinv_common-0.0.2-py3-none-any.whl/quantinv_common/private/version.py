# Standard Library
import sys

# Third Party Library
import requests


class Version(object):
    def __init__(self, major=None, minor=None, micro=None):
        self.micro = None
        self.minor = None

        # major
        self.major = int(major)
        ver = [str(major)]
        # minor
        if minor is not None:
            self.minor = int(minor)
            ver.append(str(minor))
            # micro
            if micro is not None:
                self.micro = int(micro)
                ver.append(str(micro))
        # version
        self.version = ".".join(ver)

    def __eq__(self, other):
        if isinstance(other, Version):
            if all((self.micro, other.micro)):
                return self.major == other.major and self.minor == other.minor and self.micro == other.micro
            elif all((self.minor, other.minor)):
                return self.major == other.major and self.minor == other.minor
            else:
                return self.major == other.major

        elif isinstance(other, str):
            another = self.build(version=other)
            return self == another

    def __lt__(self, other):
        if isinstance(other, Version):
            if all((self.micro, other.micro)):
                return (
                    self.major < other.major
                    or (self.major == other.major and self.minor < other.minor)
                    or (self.major == other.major and self.minor == other.minor and self.micro < other.micro)
                )
            elif all((self.minor, other.minor)):
                return self.major < other.major or (self.major == other.major and self.minor < other.minor)
            else:
                return self.major < other.major

        elif isinstance(other, str):
            another = self.build(version=other)
            return self < another

    def __gt__(self, other):
        if isinstance(other, Version):
            if all((self.micro, other.micro)):
                return (
                    self.major > other.major
                    or (self.major == other.major and self.minor > other.minor)
                    or (self.major == other.major and self.minor == other.minor and self.micro > other.micro)
                )
            elif all((self.minor, other.minor)):
                return self.major > other.major or (self.major == other.major and self.minor > other.minor)
            else:
                return self.major > other.major
        elif isinstance(other, str):
            another = self.build(version=other)
            return self > another

    def __le__(self, other):
        return self < other or self == other

    def __ge__(self, other):
        return self > other or self == other

    @staticmethod
    def build(version):
        return Version(*version_parse(version))


class PythonVersion(Version):
    def __init__(self, major=None, minor=None, micro=None):
        if not any([major, minor, micro]):
            major = sys.version_info.major
            minor = sys.version_info.minor
            micro = sys.version_info.micro
        super().__init__(major, minor, micro)

    def __repr__(self):
        return f"python version:{self.version}"


class PackageVersion(Version):
    def __init__(self, package):
        super().__init__(*version_parse(package.__version__))

    def __repr__(self):
        return f"package version:{self.version}"


# parse version str like "3.6.8" "3.6" "3"
def version_parse(version):
    dot_count = version.count(".")
    major, minor, micro = None, None, None
    if dot_count == 2:
        major, minor, micro = version.split(".")
    elif dot_count == 1:
        major, minor = version.split(".")
    else:
        major = version
    return major, minor, micro


python_version = PythonVersion()
if __name__ == "__main__":
    print(PythonVersion())
    PythonVersion(3, 6, 2)
    print(PythonVersion() > "3.6")

    print(PackageVersion(requests) > "2.27")
