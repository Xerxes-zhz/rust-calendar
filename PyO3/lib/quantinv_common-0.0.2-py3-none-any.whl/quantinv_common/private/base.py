# Standard Library
import random
from datetime import datetime, timedelta

# Third Party Library
import numpy as np
import pandas as pd


# 日期字典Mixin
class DateMapMixin:
    def __init__(self):
        # 日期映射表
        self.date_map = {}


class MapMixin(DateMapMixin):
    def __call__(self, date):
        if type(date) in [str, int]:
            # 返回单值
            return self.date_map.get(str(date), None)
        else:
            # 返回list
            # return [self.date_map.get(str(x), None) for x in date]
            if type(date) is not pd.Series:
                date = pd.Series(date).astype(str)
            return date.map(self.date_map).tolist()

    def __getitem__(self, index):
        if type(index) == slice:
            # 返回list
            # date_range = _range_date(str(index.start), str(index.stop)).strftime(r"%Y%m%d").tolist()
            # return [self.date_map.get(x, None) for x in date_range]
            date_range = pd.Series(_range_date(str(index.start), str(index.stop)).strftime(r"%Y%m%d"))
            return date_range.map(self.date_map).tolist()
        else:
            # 返回单值
            return self.date_map.get(str(index), None)


class FilterMixin(DateMapMixin):
    def __call__(self, date):
        if type(date) in [str, int]:
            # 返回单值
            return self.date_map.get(str(date), None)
        else:
            # 返回list
            arr = np.array(date).astype(str)
            mask = [self.date_map[x] for x in arr]
            return arr[mask].tolist()

    def __getitem__(self, index):
        if type(index) == slice:
            # 返回list
            begin = index.start
            end = index.stop
            date_range = np.array(_range_date(str(begin), str(end)).strftime(r"%Y%m%d").tolist())
            mask = [self.date_map[x] for x in date_range]
            return date_range[mask].tolist()
        else:
            # 返回单值
            return self.date_map.get(str(index), None)


# 将指定类型全部转换为datetime
def all_type_to_datetime(some_time):
    if type(some_time) == datetime:
        return some_time
    elif type(some_time) in [str, int]:
        return datetime.strptime(str(some_time), "%Y%m%d")
    elif type(some_time) == float:
        return datetime.fromtimestamp(some_time)


# 生成日期范围
def _range_date(begin_date, end_date):
    return pd.date_range(start=begin_date, end=end_date, freq="D")


# 生成2时间间的随机时间
def _random_time(time1, time2):
    # 返回随机的datetime.datetime
    return datetime.fromtimestamp(random.uniform(time1, time2))


# 生成某时间的边界
def _time_boundary(base_time, time_type, ):
    if low_case_match(time_type, "year"):
        begin = datetime(base_time.year, 1, 1)
        end = datetime(base_time.year + 1, 1, 1) - timedelta(days=1)

    elif low_case_match(time_type, "quarter"):
        quarter_first_month = ((base_time.month - 1) // 3) * 3 + 1
        begin = datetime(base_time.year, quarter_first_month, 1)
        end = datetime(base_time.year, quarter_first_month + 3, 1) - timedelta(days=1)

    elif low_case_match(time_type, "month"):
        begin = datetime(base_time.year, base_time.month, 1)
        if base_time.month == 12:
            end = datetime(base_time.year + 1, 1, 1) - timedelta(days=1)
        else:
            end = datetime(base_time.year, base_time.month + 1, 1) - timedelta(days=1)

    elif low_case_match(time_type, "week"):
        base_date = datetime(base_time.year, base_time.month, base_time.day)
        begin = base_date - timedelta(days=(base_time.weekday()))
        end = begin + timedelta(days=6)
    else:
        raise TypeError("time_type 不在设计范围内")
    return begin, end


# 返回指定的时间差
def _time_dalta(begin, end, methods):
    if low_case_match(methods, "datetime"):
        return end - begin
    elif low_case_match(methods, "dates"):
        return (end - begin).days + (end - begin).seconds / (24 * 3600)
    elif low_case_match(methods, "hours"):
        return (end - begin).total_seconds() / 3600
    elif low_case_match(methods, "minutes"):
        return (end - begin).total_seconds() / 60
    elif low_case_match(methods, "seconds"):
        return (end - begin).total_seconds()
    elif low_case_match(methods, "milliseconds"):
        return (end - begin).total_seconds() * 1000
    elif low_case_match(methods, "microseconds"):
        return (end - begin).total_seconds() * 1000 * 1000


# 大小写匹配
def low_case_match(a_str, b_str):
    return a_str.lower() == b_str.lower()
