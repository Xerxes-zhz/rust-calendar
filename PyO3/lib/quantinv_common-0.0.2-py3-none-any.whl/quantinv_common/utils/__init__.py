#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: XiaoZ
# @created on: 2023-06-21 17:18
# @desc  : 基础操作


# Standard Library
import os
import math


def get_filename_modifytime(path):
    """
    根据文件路径，提前文件名，文件时间等
    struct stat
    {
        dev_t       st_dev;     /* ID of device containing file -文件所在设备的ID*/
        ino_t       st_ino;     /* inode number -inode节点号*/
        mode_t      st_mode;    /* 文件的类型和存取的权限*/
        nlink_t     st_nlink;   /* number of hard links -链向此文件的连接数(硬连接)*/
        uid_t       st_uid;     /* user ID of owner -user id*/
        gid_t       st_gid;     /* group ID of owner - group id*/
        dev_t       st_rdev;    /* device ID (if special file) -设备号，针对设备文件*/
        off_t       st_size;    /* total size, in bytes -文件大小，字节为单位*/
        blksize_t   st_blksize; /* blocksize for filesystem I/O -系统块的大小*/
        blkcnt_t    st_blocks;  /* number of blocks allocated -文件所占块数*/
        time_t      st_atime;   /* time of last access -最近存取时间*/
        time_t      st_mtime;   /* time of last modification -最近修改时间*/
        time_t      st_ctime;   /* time of last status change -最后权限修改时间 */
    };
    :param path:
    :return:
    """

    file_name = os.path.split(path)[1]
    modify_time = math.floor(os.stat(path).st_mtime)
    create_time = math.floor(os.stat(path).st_mtime)
    return file_name, modify_time, create_time
