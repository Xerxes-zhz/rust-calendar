#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: XiaoZ
# @created on: 2023-06-21 19:05
# @desc  : 调优分析


# Standard Library
import time


def time_elapse(func):
    """
    计算耗时，装饰器
    """

    def _wrapper(*args, **kwargs):
        begin = time.perf_counter_ns()
        executed_result = func(*args, **kwargs)
        end = time.perf_counter_ns()
        cost = (end - begin) / 1_000_000_000
        print(f"{func.__name__} cost {cost} s \n{args} {kwargs}")
        return executed_result

    return _wrapper


class TimeElapse(object):
    """
    计算耗时，类
    """

    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        begin = time.perf_counter_ns()
        executed_result = self.func(*args, **kwargs)
        end = time.perf_counter_ns()
        cost = (end - begin) / 1_000_000_000
        print(f"{self.func.__name__} cost {cost} s \n{args} {kwargs}")
        return executed_result
