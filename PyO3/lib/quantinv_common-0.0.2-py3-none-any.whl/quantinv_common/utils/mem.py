#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: XiaoZ
# @created on: 2023-06-21 19:20
# @desc  : 内存相关


# Third Party Library

import numpy as np
import pandas as pd


def reduce_mem_usage(props):
    """
    通过改变类型自动减小df的大小，由于类型修改，尽量不要修改使用过本方法的df
    :param props: pd.Dateframe
    :return: 修改后的df
    """
    begin_mem_usg = props.memory_usage().sum() / 1024**2
    print("Memory usage of properties dataframe is :", begin_mem_usg, " MB")

    for col in props.columns:
        if props[col].dtype != object and not np.iscomplexobj(props[col]):  # Exclude strings and complex
            # Print current column type
            print("******************************")
            print("Column: ", col)
            print("dtype before: ", props[col].dtype)

            # make variables for Int, max and min
            mx = props[col].max()
            mn = props[col].min()

            # only convert finite value to int
            if not np.isfinite(props[col]).all():
                is_int = False
            else:
                # 和整数的总误差<=0.1
                is_int = np.isclose((props[col] - props[col].astype(np.int64)).sum(), 0, atol=0.1)

            # Make Integer/unsigned Integer datatypes

            if is_int:
                # Get type sequence
                if mn >= 0:
                    type_seq = (np.uint8, np.uint16, np.uint32, np.uint64)
                else:
                    type_seq = (np.int8, np.int16, np.int32, np.int64)
            else:
                # TODO 压缩优先还是精度优先，是否要保留float16
                type_seq = (np.float32, np.float64)

            for _type in type_seq:
                type_min = np.iinfo(_type).min if "float" not in str(_type) else np.finfo(_type).min
                type_max = np.iinfo(_type).max if "float" not in str(_type) else np.finfo(_type).max
                if mn > type_min and mx < type_max:
                    props[col] = props[col].astype(_type)
                    break
            else:
                # 实际上，超出最大精度的数会自动变成object，else不会触发
                # 不break触发else
                props[col] = props[col].astype(type_seq[-1])
            # Print new column type
            print("dtype after: ", props[col].dtype)
            print("******************************")

    return props


Test = False
if Test:
    # test code
    df = pd.DataFrame({"haha": [10.1, np.NAN], "xixi": [np.float32("inf"), 0.1]})
    print("Memory usage is: ", df.memory_usage().sum() / 1024**2, " MB")
    reduce_mem_usage(df)
    print("Memory usage is: ", df.memory_usage().sum() / 1024**2, " MB")
