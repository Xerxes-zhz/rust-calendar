#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: zhenglong,zhanghaozhe
# @created on: 2023-06-21 19:06
# @desc  : 时间操作的扩展


# Standard Library
import time
from datetime import datetime, timedelta

# Third Party Library

import pandas as pd

# My Library
from quantinv_common.private.base import (
    FilterMixin,
    MapMixin,
    _range_date,
    _time_dalta,
    _random_time,
    _time_boundary,
    low_case_match,
    all_type_to_datetime,
    )
from quantinv_common.private.version import python_version


# 交易日筛选
class DateFilter(FilterMixin):
    """
    日期筛选器
    : 交易日历调用
    """

    def __init__(self, calendar_obj, **kwargs):
        if python_version >= "3.10":
            macro = """
match kwargs:
    case {'filter_type': 'TradingDay'}:
        self.date_map = calendar_obj.calendar['IsTradingDay']
    case {'filter_type': 'Date', **kwargs}:
        self.date_map = self.filter_type_parse(calendar_obj.calendar, **kwargs)
                """
            exec(macro)
        else:
            if "filter_type" in kwargs:
                filter_type = kwargs["filter_type"]
                if low_case_match(filter_type, "TradingDay"):
                    self.date_map = calendar_obj.calendar["IsTradingDay"].to_dict()
                elif low_case_match(filter_type, "Date"):
                    self.date_map = self.filter_type_parse(calendar_obj.calendar, **kwargs)

    @staticmethod
    def filter_type_parse(calendar, **kwargs) -> dict:
        # TODO 数组输入支持
        date = pd.to_datetime(calendar.index)
        year_map = date.year == int(kwargs["year"]) if "year" in kwargs else True
        month_map = date.month == int(kwargs["month"]) if "month" in kwargs else True
        quarter_map = date.quarter == int(kwargs["quarter"]) if "quarter" in kwargs else True
        weekday_map = date.weekday == int(kwargs["weekday"]) if "weekday" in kwargs else True
        day_map = date.day == int(kwargs["day"]) if "day" in kwargs else True

        week_map = calendar["Week"] == int(kwargs["week"]) if "week" in kwargs else True
        df = pd.DataFrame(
            {
                "y": year_map,
                "m": month_map,
                "d": day_map,
                "w": week_map,
                "wd": weekday_map,
                "q": quarter_map,
                },
            index=calendar.index,
            )
        return df.apply(lambda row: row.all(), axis=1).to_dict()


class OrderDateFilter(object):
    """
    生成在某一周期内获取指定次序的日期筛选函数
    Note:需要注意的是，该函数完全以给定的列表筛选，所以传入的值应当是完整的周期，例如返回每月第4个日期，如果传入的值为周五的列表，就会是返回每月第4个周五
    :param range_type: 范围类型
    :param order: 次序
    """

    def __init__(self, range_type, order):
        self.range_type = range_type
        self.order = order if order < 0 else order - 1

    def __call__(self, date):
        if type(date) in [str, int]:
            return str(date)
        else:
            return self.get_order([str(x) for x in date])

    def __getitem__(self, index):
        if type(index) == slice:
            date_range = _range_date(str(index.start), str(index.stop)).strftime(r"%Y%m%d")
            return self.get_order(date_range)
        else:
            return str(index)

    def get_order(self, date_list):
        if low_case_match(self.range_type, "month"):
            key = pd.to_datetime(date_list).year.astype(str) + pd.to_datetime(date_list).month.astype(str)
        elif low_case_match(self.range_type, "week"):
            key = pd.to_datetime(date_list).year.astype(str) + pd.to_datetime(date_list).week.astype(str)
        elif low_case_match(self.range_type, "quarter"):
            key = pd.to_datetime(date_list).year.astype(str) + pd.to_datetime(date_list).quarter.astype(str)
        elif low_case_match(self.range_type, "year"):
            key = pd.to_datetime(date_list).year
        else:
            raise TypeError
        res = pd.DataFrame({"date": date_list, "key": key}).groupby(key).nth(self.order)["date"].tolist()
        return res


# 非交易日偏移映射
class ShiftMapOfDay(MapMixin):
    """
    自然日偏移
    :param delta: 偏移量，可以为0
    :param begin: 创造的日期映射对象的范围
    :param end: 创造的日期映射对象的范围
    :return: 返回一个函数，可以使用func(date), func([date_list]), func[date], func[begin:end]方式调用，根据输入的是单值还是列表返回date或date_list
    """

    def __init__(self, delta, begin, end):
        date_range = _range_date(str(begin), str(end))
        self.date_map = dict(
            zip(date_range.strftime(r"%Y%m%d"), (date_range + pd.offsets.Day(delta)).strftime(r"%Y%m%d"))
            )


def help():
    """
    帮助
    时间格式字符串
    """
    print(
        """'
%a 星期几的简写
%A 星期几的全称
%b 月分的简写
%B 月份的全称
%c 标准的日期的时间串
%C 年份的后两位数字
%d 十进制表示的每月的第几天
%D 月/天/年
%e 在两字符域中，十进制表示的每月的第几天
%F 年-月-日
%g 年份的后两位数字，使用基于周的年
%G 年分，使用基于周的年
%h 简写的月份名
%H 24小时制的小时
%I 12小时制的小时
%j 十进制表示的每年的第几天
%m 十进制表示的月份
%M 十时制表示的分钟数
%n 新行符
%p 本地的AM或PM的等价显示
%r 12小时的时间
%R 显示小时和分钟：hh:mm
%S 十进制的秒数
%t 水平制表符
%T 显示时分秒：hh:mm:ss
%u 每周的第几天，星期一为第一天 （值从0到6，星期一为0）
%U 第年的第几周，把星期日做为第一天（值从0到53）
%V 每年的第几周，使用基于周的年
%w 十进制表示的星期几（值从0到6，星期天为0）
%W 每年的第几周，把星期一做为第一天（值从0到53）
%x 标准的日期串
%X 标准的时间串
%y 不带世纪的十进制年份（值从0到99）
%Y 带世纪部分的十制年份
%z，%Z 时区名称，如果不能得到时区名称则返回空字符。
%% 百分号
        """
        )


def get_datetime(seconds=0, minutes=0, hours=0, days=0, weeks=0):
    """
    根据偏移量返回datetime.datetime，默认为now
    :param seconds: 秒
    :param minutes: 分
    :param hours: 时
    :param days: 日
    :param weeks: 周
    :return: datetime
    """
    return datetime.now() + timedelta(days=days, seconds=seconds, weeks=weeks, hours=hours, minutes=minutes)


def get_date(days=0, format=r"%Y%m%d"):
    """
    获取日期。
    :param format: 日期格式
    :param days: +1表示明天，-1表示昨天
    :return: 'None:%Y%m%d'
    """
    if days == 0:
        ret_date = datetime.now()
    else:
        ret_date = datetime.now() + timedelta(days=days)

    return ret_date.strftime(format=format)


def get_today(format=r"%Y%m%d"):
    """
    获取今天的日期
    :param format: 日期格式
    :return: 'None:%Y%m%d',
    """
    return get_date(days=0, format=format)


def get_range_date(begin_date, end_date, output_format=r"%Y%m%d"):
    """
    区间日期序列
    :param begin_date: 开始日期 需要pandas可识别的格式
    :param end_date: 结束日期 需要pandas可识别的格式
    :param output_format: 输出日期格式，默认'%Y%m%d'。
    :return: 按output_format 返回两个日期之间的所有自然日
    """

    return _range_date(str(begin_date), str(end_date)).strftime(output_format).tolist()


def convert_unix2time(timestamp: float, format: str = r"%Y%m%d", utc: int = 8):
    """
    格式转换。unix时间戳（秒）转time字符串
    :param timestamp: unix时间，秒级
    :param format: 输出时间格式
    :param utc: 时区，默认UTC+8
    :return: time-string
    """
    return time.strftime(format, time.gmtime(timestamp + utc * 3600))


def convert_time2unix(formatted_time: str, format: str = r"%Y%m%d", utc: int = 8) -> float:
    """
    格式转换。time字符串转unix时间戳（秒）
    :param formatted_time: time字符串
    :param format: 输入时间格式
    :param utc: 时区，默认UTC+8
    :return: unix时间戳（秒）
    """
    return time.mktime(time.strptime(formatted_time, format)) - utc * 3600


def shift_time(formatted_time, format, **kwargs):
    """
    通过timedelta实现时间偏移
    :param formatted_time:{str}有格式的时间
    :param format:{str}格式规则
    :param kwargs:timedelta参数
    :return: {str} formatted_time
    """
    t = datetime.strptime(formatted_time, format)
    t += timedelta(**kwargs)
    return datetime.strftime(t, format)


def get_time_delta(begin, end, methods="seconds"):
    """
    根据不同的methods返回两个时间之间的差值
    :param begin: {timestamp | number | str}
    :param end: {timestamp | number | str}
    :param  methods: {string}
    :returns: datetime:{methods}  datetime: datetime.dates | seconds: float | dates: float | microseconds: float | milliseconds: float
    """
    methods_list = [
        "datetime",
        "dates",
        "hours",
        "seconds",
        "minutes" "milliseconds" "microseconds",
        ]
    if methods not in methods_list:
        raise ValueError(f'methods must be one of{methods_list} not "{methods}"')
    begin = all_type_to_datetime(begin)
    end = all_type_to_datetime(end)
    return _time_dalta(begin, end, methods)


def get_time_boundary(base_time, time_type):
    """
    获取时间边界
    :param base_time: 基准时间 [datetime.datetime, str, int, float]
    :param time_type: 时间边界类型 ['year', 'quarter', 'month', 'week']
    :return: {datetime.datetime -> datetime.datetime} {str|int like '%Y%m%d' -> '%Y%m%d'} {float as timestamp -> float}
    """
    if type(base_time) == datetime:
        begin, end = _time_boundary(base_time, time_type)
        return begin, end
    elif type(base_time) in [str, int]:
        base_time = datetime.strptime(str(base_time), "%Y%m%d")
        begin, end = _time_boundary(base_time, time_type)
        return begin.strftime("%Y%m%d"), end.strftime("%Y%m%d")
    elif type(base_time) == float:
        base_time = datetime.fromtimestamp(base_time)
        begin, end = _time_boundary(base_time, time_type)
        return begin.timestamp(), end.timestamp()


def random_time(time1, time2):
    """
    :desc: 返回两个时间之间的随机时间
    :param time1: {datetime | int | float | str}
    :param time2: {datetime | int | float | str}
    :return: {datetime}
    """
    time1 = all_type_to_datetime(time1)
    time2 = all_type_to_datetime(time2)
    return _random_time(time1, time2)
