# Standard Library
from ftplib import FTP


# 标准的连接： server 用户名，密码，
class FTPLink(object):
    def __init__(self, server, user, password):
        self._host, self._port = server.split(":")
        self._user = user
        self._password = password
        self.ftp = FTP()
        self.connect()

    def connect(self):
        self.ftp.connect(self._host, self._port)
        self.ftp.login(self._user, self._password)

    def cwd(self, dirname):
        self.ftp.cwd(dirname)

    @property
    def files(self):
        return self.ftp.nlst()

    def quit(self):
        self.ftp.quit()
