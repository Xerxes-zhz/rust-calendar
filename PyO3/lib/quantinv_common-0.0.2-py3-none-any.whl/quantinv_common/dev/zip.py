# Standard Library
import os
import tarfile
import zipfile


def zip(file_name, files, workdir=None, file_type=None, type="zip"):
    rel_path = None
    if type == "zip":
        with zipfile.ZipFile(file_name, "w") as zip_file:
            if isinstance(files, (list, tuple)):
                for file in files:
                    if workdir is not None:
                        rel_path = os.path.relpath(file, workdir)
                    zip_file.write(file, arcname=rel_path)

            else:
                if workdir is not None:
                    rel_path = os.path.relpath(files, workdir)
                zip_file.write(files, arcname=rel_path)

    elif type == "tar":
        if file_type is None:
            file_type = "w:gz"
        with tarfile.open(file_name, file_type) as tar_file:
            if isinstance(files, (list, tuple)):
                for file in files:
                    tar_file.add(file)
            else:
                tar_file.add(files)
    pass


def unzip(
    file_name,
    target_name,
    file_type=None,
    type="zip",
):
    if type == "zip":
        with zipfile.ZipFile(file_name, "r") as zip_file:
            zip_file.extractall(path=target_name)
    elif type == "tar":
        if file_type is None:
            file_type = "r:gz"
        with tarfile.open(file_name, file_type) as tar_file:
            tar_file.extractall()

    pass
