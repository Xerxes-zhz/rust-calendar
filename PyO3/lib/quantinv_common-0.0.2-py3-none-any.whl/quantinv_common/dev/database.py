# Third Party Library
import redis
import pandas as pd
import pyodbc
from pymongo import MongoClient
from sqlalchemy import MetaData, text, create_engine
from sqlalchemy.orm import sessionmaker


class RDBMSLink(object):
    def __init__(self, db_engine, server, user, password, driver=None):
        self._db_engine = db_engine
        self._user = user
        self._password = password
        self._server = server
        self._driver = driver

    def engine(self, database, **kwargs):
        if self._driver is None:
            return create_engine(
                f"{self._db_engine}://{self._user}:{self._password}@{self._server}/{database}", **kwargs
            )
        else:
            return create_engine(
                f"{self._db_engine}://{self._user}:{self._password}@{self._server}/{database}?driver={self._driver}",
                **kwargs,
            )


class RDBMSMethods:
    @staticmethod
    def session_maker(engine):
        # 返回一个对话工厂
        # Session = self.session_maker(engine) 创建一个会话工厂
        # session = Session() 创建一个会话
        return sessionmaker(bind=engine)

    @classmethod
    def connect(cls, engine):
        return cls._conn(engine)

    @staticmethod
    def to_df(sql, engine):
        return pd.read_sql(sql, con=engine)

    # 自行管理connection的类
    class _conn(object):
        def __init__(self, engine, commit=False):
            self.engine = engine
            self.if_commit = commit
            # 自动连接，with中自动关，不用with时自己关
            self.connect = self.engine.connect()

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if self.if_commit:
                self.commit()
            self.close()

        def close(self):
            self.connect.close()

        def commit(self):
            self.connect.commit()

        def to_df(
            self,
            sql,
        ):
            return pd.read_sql(sql, con=self.connect)

        def fetchone(
            self,
            sql,
        ):
            return self.connect.execute(text(sql)).fetchone()

        def fetchall(
            self,
            sql,
        ):
            return self.connect.execute(text(sql)).fetchall()

        def execute(self, sql):
            self.connect.execute(text(sql))

        def executemany(self, sql, params):
            self.connect.execute(text(sql), params)


class MongoDB(object):
    def __init__(self, server, user=None, password=None):
        self.server = server
        self.user = user
        self.password = password

    def client(self, database, **kwargs):
        if self.user is None:
            url = f"mongodb://{self.server}/{database}"
        else:
            url = f"mongodb://{self.user}:{self.password}@{self.server}/{database}"
        return MongoClient(url, **kwargs)


class Redis(object):
    def __init__(self, server, user, password):
        self.user = user
        self.password = password
        if server.count(":") == 1:
            self.host, self.user = server.split(":")
        else:
            self.host = server
            self.port = None

    def connect(self, database, **kwargs):
        return redis.Redis(host=self.host, port=self.port, password=self.password, db=database, **kwargs)


class MySQL(RDBMSLink, RDBMSMethods):
    def __init__(self, server, user, password, driver=None):
        super().__init__("mysql+pymysql", server, user, password, driver)


class MsSQL(RDBMSLink, RDBMSMethods):
    def __init__(self, server, user, password, driver="ODBC Driver 17 for SQL Server"):
        super().__init__("mssql+pyodbc", server, user, password, driver)

    def engine(self, database, **kwargs):
        if "fast_executemany" not in kwargs:
            return super().engine(database, fast_executemany=True, **kwargs)
        else:
            return super().engine(database, **kwargs)


class PostgreSQL(RDBMSLink, RDBMSMethods):
    def __init__(self, server, user, password, driver=None):
        super().__init__("postgresql", server, user, password, driver)


class SQLite(RDBMSMethods):
    def __init__(self, path):
        self.path = path

    def engine(self, file, **kwargs):
        return create_engine(f"sqlite:///{self.path}{file}", **kwargs)

    @staticmethod
    def recreate_empty(engine):
        metadata = MetaData()
        metadata.create_all(engine)


if __name__ == "__main__":
    # MSSQL {
    print(pyodbc.drivers())
    sql = """
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE = 'BASE TABLE'
        ORDER BY TABLE_NAME;
    """
    engine = MsSQL("192.168.1.10", "zhanghaozhe", "09be3m#%").engine("dev_test")
    # with中自动创建connect，结束时自动退出
    with MsSQL.connect(engine) as conn:
        res = conn.fetchall(sql)
        print(res)

        res = conn.fetchone(sql)
        print(res)

        df = conn.to_df(sql)
        print(df)
        pass

    # SQLite
    engine = SQLite(path="../").engine(file="example.db")
    SQLite.recreate_empty(engine)
