CACHE_DIR_NAME = ".my_package_cache"
CALENDAR_CACHE_NAME = "calendar_cache.parquet"
NET_CONFIG = {"host": "192.168.230.128", "port": 8001}


def help():
    print(
        """
CACHE_DIR_NAME: 存放包的文件夹的名字
CALENDAR_CACHE_NAME: 日历对象的数据文件名
NET_CONFIG: 所需要用到的连接，目前只有CALENDAR在使用
"""
    )
