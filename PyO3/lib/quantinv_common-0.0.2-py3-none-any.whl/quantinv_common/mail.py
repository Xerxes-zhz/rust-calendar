#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: XiaoZ
# @created on: 2020/02/14 13:45
# @desc  : 邮件操作扩展


# Standard Library
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication


def send_mail(
        content,
        receivers,
        subject="python测试邮件",
        sender=None,
        pwd=None,
        attachment_list=None,
        smtp_ip="smtp.exmail.qq.com",
        smtp_port="465",
        ):
    """
    parameter
    receivers: list of target of mail.
    subject: subject of mail.
    sender: mail of sender.
    pwd: password or auth code of sender.
    attachment_list: attachment path list
    """
    msg = MIMEMultipart()
    msg["subject"] = subject
    msg["from"] = sender
    # TODO 可以使用formataddr
    msg["to"] = ",".join(receivers)
    msg.attach(MIMEText(content, "plain", "utf-8"))

    # attachment
    if attachment_list is not None:
        for attachment_path in attachment_list:
            with open(attachment_path, "rb") as attachment:
                # TODO 根据获取的application，返回特定的类型，以便于在线查看
                attachment = MIMEApplication(attachment.read(), _subtype="octet-stream")

            attachment.add_header(
                "Content-Disposition", "attachment", filename=("gbk", "", os.path.basename(attachment_path))
                )
            msg.attach(attachment)

    try:
        s = smtplib.SMTP_SSL(smtp_ip, smtp_port)
        if sender is None or pwd is None:
            raise ValueError("sender or password can't be NoneType")
        s.login(sender, pwd)
        s.sendmail(sender, receivers, msg.as_string())
        s.quit()

    except Exception as e:
        return False, f"send_main failed\t{e}"
    else:
        return True, "send_mail successful"
