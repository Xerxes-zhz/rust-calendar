#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author: XiaoZ
# @created on: 2023-06-21 17:18
# @desc  :


# Standard Library
import os
import json
import platform
from os.path import join
from functools import lru_cache

# Third Party Library
import pandas as pd

# My Library
from quantinv_common.timext import (
    MapMixin,
    DateFilter,
    FilterMixin,
    ShiftMapOfDay,
    OrderDateFilter,
    get_date,
    get_today,
    get_range_date,
)
from quantinv_common.private import http as HttpRequest
from quantinv_common.private import files, security
from quantinv_common.private.version import python_version
from quantinv_common.private.security import Warning

# 全局变量
from quantinv_common.config import CALENDAR_CACHE_NAME, NET_CONFIG  # isort: skip

os_type = platform.system()

CACHE_DIR = files.get_cache_dir(os_type)
CACHE_CALENDAR = join(CACHE_DIR, CALENDAR_CACHE_NAME)
INIT_CALENDAR = join(os.path.dirname(__file__), CALENDAR_CACHE_NAME)

# 如果缓存数据不存在，以默认数据填充
if not os.path.exists(CACHE_CALENDAR):
    pd.read_parquet(INIT_CALENDAR).to_parquet(CACHE_CALENDAR)


# 日期映射
class DateMap(MapMixin):
    """
    日期映射()
    :param calendar_obj: 需要传入日期对象
    :return: 返回一个函数，可以使用func(date), func([date_list]), func[date], func[begin:end]方式调用，根据输入的是单值还是列表返回date或date_list
    """

    def __init__(self, calendar_obj, **kwargs):
        if python_version >= "3.10":
            macro = """
match kwargs:
    case {'date_type': datebase_key}:
        self.date_map = calendar_obj.calendar[datebase_key].to_dict()
            """
            exec(macro)
        else:
            if "date_type" in kwargs:
                type_map = {
                    "tradingday": "TradingDay",
                    "year": "Year",
                    "month": "Month",
                    "week": "Week",
                    "weekday": "Weekday",
                    "nexttradingday": "NextTradingDay",
                    "prevtradingday": "PrevTradingDay",
                    "nextday": "NextDay",
                    "prevday": "PrevDay",
                    "istradingday": "IsTradingDay",
                }
                self.date_map = calendar_obj.calendar[type_map[str(kwargs["date_type"]).lower()]].to_dict()


class ShiftMapOfTradingDay(MapMixin):
    """
    交易日偏移类
    可以生成一个偏移交易日的函数
    :param delta:偏移的日期数目，0会报ValueError
    """

    def __init__(self, delta, calendar_obj):
        # 下个交易日再 向后偏移（-（dates-1））
        if delta > 1:
            tradingday = calendar_obj.tradingday
            shifted_map = pd.Series(tradingday.shift(-delta + 1).tolist(), index=tradingday)
            self.date_map = calendar_obj.calendar["NextTradingDay"].map(shifted_map).dropna()

        # 下个交易日
        elif delta == 1:
            self.date_map = calendar_obj.calendar["NextTradingDay"]

        # 0时报错，因为非交易日的本交易日不存在
        elif delta == 0:
            raise ValueError(
                "TradingDay shifter can't shift 0 dates, because the day to be shifted could be a  non-tradingday"
            )
        # 上个交易日
        elif delta == -1:
            self.date_map = calendar_obj.calendar["PrevTradingDay"]

        # 上个交易日 向前偏移（-（dates+1））
        elif delta < -1:
            tradingday = calendar_obj.tradingday
            shifted_map = pd.Series(tradingday.shift(-delta - 1).tolist(), index=tradingday)
            self.date_map = calendar_obj.calendar["PrevTradingDay"].map(shifted_map).dropna()


# 日历对象
class Calendar(object):
    """
    日历对象
    Note: 注解中的{date}代表"%Y%m%d"的str类型
    """

    def __init__(self) -> None:
        self.host = NET_CONFIG["host"]
        self.port = NET_CONFIG["port"]
        self._calendar_df = pd.DataFrame()
        # 初始化时自动连接并获取一次
        # calendar.index是TradingDay
        self.update_offline()

        begin = self.calendar.index.values[0]
        end = self.calendar.index.values[-1]
        self._calendar_begin = begin
        self._calendar_end = end

    @staticmethod
    def _get_tradingday(calendar: pd.DataFrame) -> pd.Series:
        """
        :desc: 获取交易日series序列
        :param {df} calendar
        :return {series}
        """
        security.InputCheck.type_check(calendar, pd.DataFrame)
        return calendar.index[calendar["IsTradingDay"]].to_series()

    @staticmethod
    def _get_day(calendar: pd.DataFrame) -> pd.Series:
        return calendar.index.to_series()

    @property
    def calendar(self):
        """
        :desc: 返回交易日历的df
        :return {df}
        """
        return self._calendar_df

    @property
    def tradingday(self):
        """
        获取日历中完整的交易日序列
        :return: {series}
        """
        return Calendar._get_tradingday(self.calendar)

    @property
    def day(self):
        """
        获取日历中完整的自然日列表
        :return: {series}
        """
        return Calendar._get_day(self.calendar)

    def update_offline(self):
        """
        从本地缓存更新calendar对象里的df
        :return:
        """
        self._calendar_df = pd.read_parquet(CACHE_CALENDAR)
        self.cache_clear()

    def update(self, latest=False):
        """
        获取交易日历（针对于从数据库的获取时间，可选最新数据为当日数据或即时数据）
        :param {str} latest: {True:刷新数据库数据, False:不刷新数据库，也就是当日最新的数据库数据}
        """

        # 获取今天的交易日历
        def _acquire_today_calendar():
            calendar_api = "/api/get_calendar"
            url = f"http://{self.host}:{self.port}{calendar_api}"
            return pd.DataFrame.from_dict(json.loads(HttpRequest.get(url, timeout=5, max_retries=3).json()))

        # 获取最新交易日历
        def _acquire_now_calendar():
            calendar_api = "/api/get_latest_calendar"
            url = f"http://{self.host}:{self.port}{calendar_api}"
            return pd.DataFrame.from_dict(json.loads(HttpRequest.get(url, timeout=5, max_retries=3).json()))

        try:
            if latest:
                self._calendar_df = _acquire_now_calendar()
            else:
                self._calendar_df = _acquire_today_calendar()
            self._calendar_df = self._calendar_df.convert_dtypes()
            self._calendar_df = self._calendar_df.set_index("TradingDay")
            self._calendar_df.to_parquet(CACHE_CALENDAR)
        except:
            Warning.warn("获取最新数据失败，自动获取本地数据")
            self.update_offline()
            return
        else:
            self.cache_clear()

        if self._calendar_df is None or self._calendar_df.__len__() == 0:
            raise security.DataExistsError(f"calendar is empty")

    def is_tradingday(self, dates):
        """
        是否是交易日
        :param dates: 单值或列表
        :return: 按照顺序返回单值或列表的是否是交易日的True False 列表
        """
        return self.DateGetter(date_type="IsTradingDay")(dates)

    def get_dates(self, delta, trading, dates=None):
        """
        根据需求返回日期偏移
        :param delta: 偏移量
        :param trading: 交易日还是非交易日
        :param dates: 被偏移的日期，可以是单值也可以是个列表
        :return: 返回计算出的单值或列表
        """
        dates = self.today if dates is None else dates
        return self.DateShifter(delta=delta, trading=trading)(dates)

    def get_dates_map(self, delta, trading):
        """
        根据需求返回日期偏移
        :param delta: 偏移量
        :param trading: 交易日还是非交易日
        :param dates: 被偏移的日期，可以是单值也可以是个列表
        :return: 返回计算出的单值或列表
        """
        return self.DateShifter(delta=delta, trading=trading).date_map

    def prev_day(self, dates=None):
        """
        前一个自然日
        :param dates: 单值或列表，默认为today
        :return: 返回对应的前一个自然日的列表或单值
        """
        return self.get_dates(delta=-1, trading=False, dates=dates)

    def next_day(self, dates=None):
        """
        下一个自然日
        :param dates: 单值或列表，默认为today
        :return: 返回对应的下一个自然日的列表或单值
        """
        return self.get_dates(delta=1, trading=False, dates=dates)

    def prev_tradingday(self, dates=None):
        """
        前一个交易日
        :param dates: 单值或列表，默认为today
        :return: 返回对应的前一个交易日的列表或单值
        """
        return self.get_dates(delta=-1, trading=True, dates=dates)

    def next_tradingday(self, dates=None):
        """
        下一个交易日
        :param dates: 单值或列表，默认为today
        :return: 返回对应的下一个交易日的列表或单值
        """
        return self.get_dates(delta=1, trading=True, dates=dates)

    def tradingday_filter(self, dates):
        """
        交易日筛选器
        :param dates:
        :return:
        """
        dates = self.today if dates is None else dates
        return self.DateFilter(filter_type="TradingDay")(dates)

    @property
    def latest_tradingday(self):
        """
        返回最新交易日（今天 或 今天的上个交易日）
        :return {date}
        """
        if self.is_tradingday(self.today):
            return self.today
        else:
            return self.prev_tradingday(self.today)

    @property
    def today(self):
        """
        今天的日期
        :return: {date}
        """
        return get_today()

    @property
    def get_date(days=0, format=r"%Y%m%d"):
        return get_date(days=days, format=format)

    @property
    def get_range_date(begin_date, end_date, output_format=r"%Y%m%d"):
        return get_range_date(begin_date=begin_date, end_date=end_date, output_format=output_format)

    def cache_clear(self):
        """
        缓存清理，自动清理Calendar类中所有应用到缓存的函数
        """
        self.DateShifter.cache_clear()
        self.DateGetter.cache_clear()
        self.DateFilter.cache_clear()
        self.OrderDateFilter.cache_clear()

    @lru_cache(maxsize=128)
    def DateShifter(self, delta, trading=False, begin=None, end=None):
        """
        日期偏移器
        :param delta: 偏移日期，注意交易日不能取0
        :param trading: 是否是交易日
        :param begin: 非交易日时的起始时间，默认为Calendar对象的开始时间
        :param end: 非交易日时的结束时间，默认为Calendar对象的结束时间
        :return: 映射对象
        """
        if trading:
            return ShiftMapOfTradingDay(delta, calendar_obj=self)
        else:
            if begin is None:
                begin = self._calendar_begin
            if end is None:
                end = self._calendar_end
            return ShiftMapOfDay(delta, begin, end)

    @lru_cache(maxsize=128)
    def DateGetter(self, **kwargs) -> object:
        """
        日期获取器
        :param kwargs: Calendar中的df的column ['Year', 'Month', 'Week', 'Weekday', 'NextTradingDay', 'PrevTradingDay', 'NextDay', 'PrevDay', 'IsTradingDay']
        :return: 映射对象
        """
        return DateMap(calendar_obj=self, **kwargs)

    @lru_cache(maxsize=128)
    def DateFilter(self, **kwargs):
        """
        日期筛选器
        :param kwargs: year, month 1~12, day 1~31, quarter 1~4, weekday 0~6, week 0~52
        :return: 筛选对象
        """
        return DateFilter(calendar_obj=self, **kwargs)

    @lru_cache(maxsize=128)
    def OrderDateFilter(self, range_type, order):
        """
        周期范围内容的日期筛选器
        :param range_type: 周期类型 ['month', 'year', 'quarter', 'week']
        :param order: 次序
        :return: 筛选对象
        """
        return OrderDateFilter(range_type, order)

    def get_dates_from(self, days, trading, begin=None):
        """
        获取从begin开始(包括begin）的days总数的交易日/自然日的列表
        :param days: 不能是0，正负代表之前还是之后，其绝对值代表返回的天数
        :param trading: True：交易日 False:自然日
        :param begin: 起始日期
        :return:
        """
        begin = self.today if begin is None else begin
        if days == 0:
            raise ValueError("days的绝对值代表返回的总天数，不能是0")
        else:
            # 对于begin是非交易日，获取n个交易日时日期的绝对值不用减1
            if not self.is_tradingday(begin) and trading:
                pass
            # 其他情况因为包括当天，所以要减1
            else:
                days = days - 1 if days > 0 else days + 1

        if days != 0:
            end = self.DateShifter(delta=days, trading=trading)(begin)
        else:
            end = begin

        if days < 0:
            begin, end = end, begin

        if trading:
            return self.DateFilter(filter_type="TradingDay")[begin:end]
        else:
            return get_range_date(begin, end)


if __name__ == "__main__":
    # 测试代码在quantinv_common\test.py
    c = Calendar()
    c.get_dates(delta=1, trading=True)
    pass
